package com.example.washmachinedemo.util;

public class Constant
{
    public static final String SPIN = "Spin";
    public static final String WASH = "Wash";
    
    private Constant() {
        throw new IllegalStateException("Utility Class");
    }
}
